/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.interfaces;

/**
 *
 * @author GLNN104Lab
 */
public interface DoStuff {
    public String sayHowdy();
    public String sayHowdyLots(int x);
    public int getANumber(int x);
}
