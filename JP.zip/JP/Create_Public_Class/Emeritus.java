/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package my.profs;

/**
 *
 * @author Anthony
 */
public class Emeritus extends Professors{
    String retireYear;
    
    public String lecture(){
        return "Ponder Ponder Ponder";
    }// end lecture
}// end class Emeritus